# Páginas informativas Google OAuth

Preparadas 21Oct2026. Sin publicar. Colocar index.html y privacidad.html juntos en alojamiento HTTPS público. Inicio enlaza privacidad y ambas identifican al responsable. No contienen secretos, identificadores privados, cuentas ni acceso al bot.

Revisión técnica: scopes documents y drive.file leídos sin exportar tokens; bridge limita documentos configurados y carpeta de evidencias. Las páginas describen la conexión del HP, no todas las herramientas/hilos del proyecto. No afirman certificación legal ni aprobación Google.

Falta decidir dominio/alojamiento bajo control del propietario. Si Google exige verificar dominio, acreditar propiedad con Search Console; una URL visible no prueba propiedad. No usar el dominio de eToro ni publicar dashboard o puertos HP. Tras publicación comprobar ambas páginas sin login, añadir URLs a Branding y dominio autorizado cuando corresponda. Luego comprobar publicación OAuth y reautorizar HP con mismos permisos. No garantiza aceptación o renovación indefinida.
